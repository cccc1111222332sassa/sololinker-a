#! /bin/sh

# docker run -it --platform linux/arm/v7 -v /Users/wangjun/Desktop/docker/alpine:/home alpine:3.19

# 切换源
sed -i 's/dl-cdn.alpinelinux.org/mirrors.aliyun.com/g' /etc/apk/repositories

# 安装基础包
apk update
apk add openrc agetty openssh util-linux bash bash-completion e2fsprogs-extra
apk cache clean

# 添加启动项
rc-update add devfs boot
rc-update add procfs boot
rc-update add sysfs boot
rc-update add networking default
rc-update add sshd default

# 创建导出目录
mkdir -p /home/rootfs && rm -rf /home/rootfs/*

# 准备文件系统
for d in bin etc lib media sbin usr; do tar c "$d" | tar x -C /home/rootfs; done
for dir in dev opt proc root run sys var; do mkdir /home/rootfs/${dir}; done

# 合并修改项
echo copy patchs
cp -rf /home/patchs/* /home/rootfs

# 导出文件系统
echo export rootfs
cd /home/rootfs/ && tar czf rootfs_ubuntu.tar.gz *